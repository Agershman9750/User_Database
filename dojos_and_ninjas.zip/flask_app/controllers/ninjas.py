from flask import render_template, request, redirect
from flask_app import app
from flask_app.models import dojo, ninja


@app.route('/ninjas')
def ninjas():
    return render_template('ninja.html', dojos=dojo.Dojo.get_all())


@app.route('/add_ninja', methods=['POST'])
def add_ninja():
    data = {
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'age': request.form['age'],
        'dojo_id': request.form['dojo_id']
    }
    ninja.Ninja.save(data)
    return redirect(f"/dojos/{data['dojo_id']}")
