from flask import render_template, request, redirect
from flask_app import app
from flask_app.models import dojo, ninja


@app.route('/dojos')
def dojos():
    return render_template('dojo.html', dojos=dojo.Dojo.get_all())


@app.route('/add_dojo', methods=['POST'])
def add_dojo():
    name = request.form['name']
    data = {
        'name': name
    }
    dojo.Dojo.save(data)
    return redirect('/dojos')


@app.route('/dojos/<int:dojo_id>')
def show_dojo(dojo_id):
    dojo_data = dojo.Dojo.get_one({'id': dojo_id})
    ninjas_data = ninja.Ninja.get_by_dojo({'dojo_id': dojo_id})
    return render_template('dojo_ninjas.html', dojo=dojo_data, ninjas=ninjas_data)
